#include <iostream>

int factorial(int value)
{
    if (value == 1)
        return 1;
    return factorial(value - 1) * value;
}

int main()
{
    std::cout << "Enter an integer value ";
    int value;
    std::cin >> value;

    std::cout << "The answer is: " << factorial(value);
}
