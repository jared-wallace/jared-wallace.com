#include <iostream>

int fibo(int value, int m[])
{
    if (value == 0)
        return 0;
    if (value == 2 || value == 1)
        return 1;
    return ( fibo(value - 1, m) + fibo(value - 2, m) );




    // An alternative approach that uses memory to speed up (dramatically)
    // the algorithm.
    /*
     *if (value == 0)
     *    return m[0];
     *if (value == 1)
     *    return m[1];
     *if (m[value-2] == 0)
     *    fibo(value-2, m);
     *if (m[value-1] != 0)
     *    fibo(value-1, m);
     *m[value] = m[value-1] + m[value-2];
     *return m[value];
     */
}

int main()
{
    int m[2000000];
    for (int i = 0; i < 2000000; i++)
        m[i] = 0;
    m[0] = 1;
    m[1] = 1;
    std::cout << "Please enter the quantity of fibonacci numbers to display. ";
    int value;
    std::cin >> value;
    for (int i = 0; i < value; i++)
        std::cout << fibo(i, m) << " ";
}
