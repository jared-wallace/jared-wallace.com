/*
 *A simple exponentiation tool
 *Author: Jared Wallace
 *Date: 09-23-2014
 *Section: 18
 */
#include <iostream>

using namespace std;

int main()
{
    int base = 0;
    int exponent = 0;
    int counter = 0;
    int answer = 1;

    cout << "Please enter the base ";
    cin >> base;
    cout << "Please enter the exponent ";
    cin >> exponent;

    while(counter < exponent)
    {
        answer = answer * base;
        counter++;
    }

    cout << "The result of " << base << " to the power of " << exponent;
    cout << " is: " << answer;
}
