/*
 *Author: Jared Wallace
 *Date: 09-23-2014
 *Section: 18
 *
 *This program is a simple guessing game.
 */

#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;

int main()
{
    int min_value = 1;
    int max_value = 1;
    int guess = 0;
    int counter = 1;
    char cont = 'y';
    srand (time(NULL));

    do
    {
        counter = 1;
        cout << "Welcome to the guessing game!" << endl;
        cout << "Please enter the lower number of the range from which you ";
        cout << "wish to guess ";
        cin >> min_value;
        cout << "Please enter the higher number of the range from which you ";
        cout << "wish to guess ";
        cin >> max_value;
        int secretNumber = rand() % max_value + min_value;
        cout << "Please enter the your first guess!";
        cin >> guess;

        while (guess != secretNumber)
        {
            cout << "Sorry, that guess was ";
            if (guess < min_value || guess > max_value)
                cout << "out of range.";
            else if (guess < secretNumber)
                cout << "too low.";
            else
                cout << "too high.";

            cout << " Please guess again. ";
            cin >> guess;

            counter++;
        }

        cout << "Congratulations, it (only) took you " << counter;
        cout << " tries to guess the correct number!" << endl;
        cout << "Would you like to play again? ";
        cin >> cont;
    }while(cont == 'y' || cont == 'Y');

    return EXIT_SUCCESS;
}
