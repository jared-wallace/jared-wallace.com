#include <iostream>

int sumNumbers(int val)
{
    if (val == 2)
        return 3;
    return ( val + sumNumbers(val-1) );
}

int main()
{
    std::cout << "Enter the ending value of the numbers to sum: ";
    int val;
    std::cin >> val;
    std::cout << "The result is " << sumNumbers(val);
}
