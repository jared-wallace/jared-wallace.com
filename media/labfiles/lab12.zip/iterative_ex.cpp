#include <iostream>

int main()
{
    std::cout << "Enter the ending value of the numbers to sum: ";
    int val;
    std::cin >> val;
    int result = ( (val+1)*val ) / 2;
    std::cout << "The result is " << result;
    return 0;
}
