#!/usr/bin/python
print "Content-type: text/html\n\n"
print "<html>

print "<ul>"

# insert code here. Each printed line should look like the following:
# <li><a href="INSERT LINK HERE">INSERT TITLE HERE</a></li>

print </html>
