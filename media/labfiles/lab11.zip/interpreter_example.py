#!/usr/bin/python

# This program illustrates the interpreted nature
# of Python.

# We "include" libraries with import
import sys

def repeat(name):
    result = name * 10
    return result


def main():
    if len(sys.argv) > 1:
        name = sys.argv[1]
        if name == "Guido":
            # Unless the name is Guido, this obvious error causes
        # no issues
            print repeeet(name) + '!!!'
        else:
            print repeat(name)
    else:
        print "Usage: ./interpreter_example.py [SOME NAME HERE]"

# Standard boilerplate to call the main() function to begin
# the program.
if __name__ == '__main__':
    main()
