// Insert your header here

#include <iostream>
#include <cstdlib>
#include <time.h>

using namespace std;
void clear_screen();

int main()
{
    // The number of rows and columns
    const int ROWS = 10;
    const int COLS = 10;
    // The board that will be displayed
    char life[ROWS][COLS];
    // Initialize our board to all blanks
    for (int i = 0; i < ROWS; i++)
    {
        // everything here happens once per row
        for (int j = 0; j < COLS; j++)
        {
            //everything here happens once per column (per row)
            life[i][j] = ' ';
        }
    }

    // We utilize the pseudo random number generator to generate
    // our initial game state
    srand ( time(NULL) );
    int cell;
    // Nested for loops since we have a two-dimensional array
    for(int r = 0; r < ROWS; r++)
    {
        for(int c = 0; c < COLS; c++)
        {
            cell = rand() % 7;
            if(cell >= 5)
            {
                life[r][c] = '*';
            }
            else
            {
                life[r][c]=' ';
            }
        }
    }

    /*
     * Now you have an initialized game board. You need to accomplish two
     * main tasks: Write the code to print out each generation, and set up
     * your "processor", which applies the rules already established
     * (think switch statement).
     */


    /* To print the array, you'll need a double for loop, similar to
     * the original initialization (line  18), except that you won't
     * be setting values, instead you will be printing them.
     */


    /* For the processing section, break it into 3 parts. Again, you
     * will need a double for loop here. Part 1 is "neighbor checking".
     * For each "cell", you need to examine all 8 neighbors, and count
     * the number that are alive (we'll discuss edge cases together).
     *
     * Part 2 is applying the rules of the game to each cell, according
     * to the neighbor total you calculated in part 1. When you apply
     * the appropriate rule, you cannot simply overwrite the original
     * "life" array! You'll need to store the new "alive or dead" value
     * to an entirely new array.
     *
     * Part 3 is where you copy each element, or cell, of the new array
     * into the old array. This prepares the "life" array to be printed,
     * as it now contains the next generation of the game.
     */
    
    
    
    
    
    /*
     * I have written a simple function to clear the
     * screen, and  I've left a sample invocation below.
     *
     * YOU DO NOT HAVE TO USE THIS!
     *
     * It is provided solely as a convenience.
     */
    clear_screen();

    return 0;
}

void clear_screen()
{
    cout << string(90, '\n');
}
