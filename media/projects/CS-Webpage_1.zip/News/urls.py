<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<title>
computer-science-web/news/urls.py at profile_improvements - CS / Computer Science Web | 
GitLab
</title>
<link href="/assets/favicon-220424ba6cb497309f8faf8545eb5408.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<link href="/assets/application-813210a046db0add6f14de3f24064270.css" media="all" rel="stylesheet" />
<link href="/assets/print-133dbf6c5049e528c5ed63754a3c2ae7.css" media="print" rel="stylesheet" />
<script src="/assets/application-c829d5570fd54ca20cb3a55ba2620093.js"></script>
<meta content="authenticity_token" name="csrf-param" />
<meta content="xVN+NuZzUFfTo5oDpkGPPpvr8Wns4r3eOcouRDJ15C4=" name="csrf-token" />
<script type="text/javascript">
//<![CDATA[
window.gon={};gon.default_issues_tracker="gitlab";gon.api_version="v3";gon.api_token="u8yaxDNCtxabyW2fEe62";gon.gravatar_url="http://www.gravatar.com/avatar/%{hash}?s=%{size}\u0026d=mm";gon.relative_url_root="";gon.gravatar_enabled=true;
//]]>
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">




</head>

<body class='ui_color project' data-page='projects:blob:show' data-project-id='140'>

<header class='navbar navbar-static-top navbar-gitlab'>
<div class='navbar-inner'>
<div class='container'>
<div class='app_logo'>
<span class='separator'></span>
<a class="home has_bottom_tooltip" href="/" title="Dashboard"><h1>GITLAB</h1>
</a><span class='separator'></span>
</div>
<h1 class='title'><span><a href="/groups/cs">CS</a> / Computer Science Web</span></h1>
<button class='navbar-toggle' data-target='.navbar-collapse' data-toggle='collapse' type='button'>
<span class='sr-only'>Toggle navigation</span>
<i class='icon-reorder'></i>
</button>
<div class='navbar-collapse collapse'>
<ul class='nav navbar-nav'>
<li class='hidden-sm hidden-xs'>
<div class='search'>
<form accept-charset="UTF-8" action="/search" class="navbar-form pull-left" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
<input class="search-input" id="search" name="search" placeholder="Search in this project" type="text" />
<input id="group_id" name="group_id" type="hidden" />
<input id="project_id" name="project_id" type="hidden" value="140" />
<input id="search_code" name="search_code" type="hidden" value="true" />
<input id="repository_ref" name="repository_ref" type="hidden" value="profile_improvements" />

<div class='search-autocomplete-opts hide' data-autocomplete-path='/search/autocomplete' data-autocomplete-project-id='140' data-autocomplete-project-ref='profile_improvements'></div>
</form>

</div>

</li>
<li class='visible-sm visible-xs'>
<a class="has_bottom_tooltip" data-original-title="Search area" href="/search" title="Search"><i class='icon-search'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="Public area" href="/public" title="Public area"><i class='icon-globe'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="My snippets" href="/s/jlw213" title="My snippets"><i class='icon-paste'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="New project" href="/projects/new" title="New project"><i class='icon-plus'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="Profile settings&quot;" href="/profile" title="Profile settings"><i class='icon-user'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-method="delete" data-original-title="Logout" href="/users/sign_out" rel="nofollow" title="Logout"><i class='icon-signout'></i>
</a></li>
<li>
<a class="profile-pic" href="/u/jlw213" id="profile-pic"><img alt="User activity" src="http://www.gravatar.com/avatar/a3d8a0e7d3fa525a5ee4612ae780c77c?s=26&amp;d=mm" />
</a></li>
</ul>
</div>
</div>
</div>
</header>

<script>
  GitLab.GfmAutoComplete.dataSource = "/cs/computer-science-web/autocomplete_sources?type=NilClass&type_id=profile_improvements%2Fnews%2Furls.py"
  GitLab.GfmAutoComplete.setup();
</script>

<div class='flash-container'>
</div>


<nav class='main-nav navbar-collapse collapse'>
<div class='container'><ul>
<li class="home"><a href="/cs/computer-science-web" title="Project"><i class='icon-home'></i>
</a></li><li class="active"><a href="/cs/computer-science-web/tree/profile_improvements">Files</a>
</li><li class=""><a href="/cs/computer-science-web/commits/profile_improvements">Commits</a>
</li><li class=""><a href="/cs/computer-science-web/network/profile_improvements">Network</a>
</li><li class=""><a href="/cs/computer-science-web/graphs/profile_improvements">Graphs</a>
</li><li class=""><a href="/cs/computer-science-web/issues">Issues
<span class='count issue_counter'>0</span>
</a></li><li class=""><a href="/cs/computer-science-web/merge_requests">Merge Requests
<span class='count merge_counter'>1</span>
</a></li><li class=""><a href="/cs/computer-science-web/wikis/home">Wiki</a>
</li><li class=""><a class="stat-tab tab " href="/cs/computer-science-web/edit">Settings
</a></li></ul>
</div>
</nav>
<div class='container'>
<div class='content'><div class='tree-ref-holder'>
<form accept-charset="UTF-8" action="/cs/computer-science-web/refs/switch" class="project-refs-form" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
<select class="project-refs-select select2 select2-sm" id="ref" name="ref"><optgroup label="Branches"><option value="cms">cms</option>
<option value="development">development</option>
<option value="exch_calendar">exch_calendar</option>
<option value="google_calendar">google_calendar</option>
<option value="landing-page-adjustment">landing-page-adjustment</option>
<option value="master">master</option>
<option value="news">news</option>
<option selected="selected" value="profile_improvements">profile_improvements</option>
<option value="readme">readme</option>
<option value="ui_improvements">ui_improvements</option></optgroup><optgroup label="Tags"></optgroup></select>
<input id="destination" name="destination" type="hidden" value="blob" />
<input id="path" name="path" type="hidden" value="news/urls.py" />
</form>


</div>
<div class='tree-holder' id='tree-holder'>
<ul class='breadcrumb'>
<li>
<i class='icon-angle-right'></i>
<a href="/cs/computer-science-web/tree/profile_improvements">computer-science-web
</a></li>
<li>
<a href="/cs/computer-science-web/tree/profile_improvements/news">news</a>
</li>
<li>
<a href="/cs/computer-science-web/blob/profile_improvements/news/urls.py"><span class='cblue'>
urls.py
</span>
</a></li>
</ul>
<ul class='blob-commit-info bs-callout bs-callout-info'>
<li class='commit js-toggle-container'>
<div class='commit-row-title'>
<a class="commit_short_id" href="/cs/computer-science-web/commit/9e0ad32904c40a1d7cc83293269ae98bf72321c1">9e0ad3290</a>
&nbsp;
<span class='str-truncated'>
<a class="commit-row-message" href="/cs/computer-science-web/commit/9e0ad32904c40a1d7cc83293269ae98bf72321c1">Email is fixed and working, still needs some polishing</a>
</span>
<a class="pull-right" href="/cs/computer-science-web/tree/9e0ad32904c40a1d7cc83293269ae98bf72321c1">Browse Code »</a>
<div class='notes_count'>
</div>
</div>
<div class='commit-row-info'>
<a class="commit-author-link has_tooltip" data-original-title="jaredw@cs.txstate.edu" href="mailto:jaredw@cs.txstate.edu"><img alt="" class="avatar s16" src="http://www.gravatar.com/avatar/317e151a104e397c713348dbff67ee41?s=16&amp;d=mm" width="16" /> <span class="commit-author-name">Jared Wallace</span></a>
<div class='committed_ago'>
<time class='time_ago' data-placement='top' data-toggle='tooltip' datetime='2014-05-20T21:08:34Z' title='May 20, 2014 4:08pm'>2014-05-20 16:08:34 -0500</time>
<script>$('.time_ago').timeago().tooltip()</script>
 &nbsp;
</div>
</div>
</li>

</ul>
<div class='tree-content-holder' id='tree-content-holder'>
<div class='file-holder'>
<div class='file-title'>
<i class='icon-file'></i>
<span class='file_name'>
urls.py
<small>448 Bytes</small>
</span>
<span class='options'><div class='btn-group tree-btn-group'>
<a class="btn btn-small" href="/cs/computer-science-web/edit/profile_improvements/news/urls.py">edit</a>
<a class="btn btn-small" href="/cs/computer-science-web/raw/profile_improvements/news/urls.py" target="_blank">raw</a>
<a class="btn btn-small" href="/cs/computer-science-web/blame/profile_improvements/news/urls.py">blame</a>
<a class="btn btn-small" href="/cs/computer-science-web/commits/profile_improvements/news/urls.py">history</a>
<a class="remove-blob btn btn-small btn-remove" data-toggle="modal" href="#modal-remove-blob">remove
</a></div>
</span>
</div>
<div class='file-content code'>
<div class='highlighted-data solarized-dark'>
<div class='line-numbers'>
<a href="#L1" id="L1" rel="#L1"><i class='icon-link'></i>
1
</a><a href="#L2" id="L2" rel="#L2"><i class='icon-link'></i>
2
</a><a href="#L3" id="L3" rel="#L3"><i class='icon-link'></i>
3
</a><a href="#L4" id="L4" rel="#L4"><i class='icon-link'></i>
4
</a><a href="#L5" id="L5" rel="#L5"><i class='icon-link'></i>
5
</a><a href="#L6" id="L6" rel="#L6"><i class='icon-link'></i>
6
</a><a href="#L7" id="L7" rel="#L7"><i class='icon-link'></i>
7
</a><a href="#L8" id="L8" rel="#L8"><i class='icon-link'></i>
8
</a><a href="#L9" id="L9" rel="#L9"><i class='icon-link'></i>
9
</a><a href="#L10" id="L10" rel="#L10"><i class='icon-link'></i>
10
</a><a href="#L11" id="L11" rel="#L11"><i class='icon-link'></i>
11
</a></div>
<div class='highlight'>
<pre><code>from django.conf.urls import patterns, url, include
from news.forms import PostForm
from news import views

urlpatterns = patterns('news.views',
    url(r'^add/$', 'add_post', name='add_post'),
    url(r'^detail/(?P&lt;id&gt;\d)/', 'detail', name=&quot;detail&quot;),
    url(r'^edit/(?P&lt;id&gt;\d)/', 'edit_post', name=&quot;edit_post&quot;),
    url(r'^view_all/$', 'view_all', name=&quot;view_all&quot;),
    url(r'^send_email/(?P&lt;id&gt;\d)/', 'email_announcement', name=&quot;send_email&quot;),
)</code></pre>
</div>
</div>

</div>

</div>
</div>

</div>
<div class='modal hide' id='modal-remove-blob'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header'>
<a class='close' data-dismiss='modal' href='#'>×</a>
<h3 class='page-title'>Remove urls.py</h3>
<p class='light'>
From branch
<strong>profile_improvements</strong>
</p>
</div>
<div class='modal-body'>
<form accept-charset="UTF-8" action="/cs/computer-science-web/blob/profile_improvements/news/urls.py" class="form-horizontal" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="_method" type="hidden" value="delete" /><input name="authenticity_token" type="hidden" value="xVN+NuZzUFfTo5oDpkGPPpvr8Wns4r3eOcouRDJ15C4=" /></div>
<div class='form-group commit_message-group'>
<label class="control-label" for="commit_message">Commit message
</label><div class='col-sm-10'>
<textarea class="form-control" id="commit_message" name="commit_message" placeholder="Removed this file because..." required="required" rows="3">
</textarea>
</div>
</div>
<div class='form-group'>
<div class='col-sm-2'></div>
<div class='col-sm-10'>
<input class="btn btn-remove" name="commit" type="submit" value="Remove file" />
<a class="btn btn-cancel" data-dismiss="modal" href="#">Cancel</a>
</div>
</div>
</form>

</div>
</div>
</div>
</div>

</div>
</div>
</body>
</html>
