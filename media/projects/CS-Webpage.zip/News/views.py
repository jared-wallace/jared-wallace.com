<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<title>
computer-science-web/news/views.py at profile_improvements - CS / Computer Science Web | 
GitLab
</title>
<link href="/assets/favicon-220424ba6cb497309f8faf8545eb5408.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
<link href="/assets/application-813210a046db0add6f14de3f24064270.css" media="all" rel="stylesheet" />
<link href="/assets/print-133dbf6c5049e528c5ed63754a3c2ae7.css" media="print" rel="stylesheet" />
<script src="/assets/application-c829d5570fd54ca20cb3a55ba2620093.js"></script>
<meta content="authenticity_token" name="csrf-param" />
<meta content="xVN+NuZzUFfTo5oDpkGPPpvr8Wns4r3eOcouRDJ15C4=" name="csrf-token" />
<script type="text/javascript">
//<![CDATA[
window.gon={};gon.default_issues_tracker="gitlab";gon.api_version="v3";gon.api_token="u8yaxDNCtxabyW2fEe62";gon.gravatar_url="http://www.gravatar.com/avatar/%{hash}?s=%{size}\u0026d=mm";gon.relative_url_root="";gon.gravatar_enabled=true;
//]]>
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">




</head>

<body class='ui_color project' data-page='projects:blob:show' data-project-id='140'>

<header class='navbar navbar-static-top navbar-gitlab'>
<div class='navbar-inner'>
<div class='container'>
<div class='app_logo'>
<span class='separator'></span>
<a class="home has_bottom_tooltip" href="/" title="Dashboard"><h1>GITLAB</h1>
</a><span class='separator'></span>
</div>
<h1 class='title'><span><a href="/groups/cs">CS</a> / Computer Science Web</span></h1>
<button class='navbar-toggle' data-target='.navbar-collapse' data-toggle='collapse' type='button'>
<span class='sr-only'>Toggle navigation</span>
<i class='icon-reorder'></i>
</button>
<div class='navbar-collapse collapse'>
<ul class='nav navbar-nav'>
<li class='hidden-sm hidden-xs'>
<div class='search'>
<form accept-charset="UTF-8" action="/search" class="navbar-form pull-left" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
<input class="search-input" id="search" name="search" placeholder="Search in this project" type="text" />
<input id="group_id" name="group_id" type="hidden" />
<input id="project_id" name="project_id" type="hidden" value="140" />
<input id="search_code" name="search_code" type="hidden" value="true" />
<input id="repository_ref" name="repository_ref" type="hidden" value="profile_improvements" />

<div class='search-autocomplete-opts hide' data-autocomplete-path='/search/autocomplete' data-autocomplete-project-id='140' data-autocomplete-project-ref='profile_improvements'></div>
</form>

</div>

</li>
<li class='visible-sm visible-xs'>
<a class="has_bottom_tooltip" data-original-title="Search area" href="/search" title="Search"><i class='icon-search'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="Public area" href="/public" title="Public area"><i class='icon-globe'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="My snippets" href="/s/jlw213" title="My snippets"><i class='icon-paste'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="New project" href="/projects/new" title="New project"><i class='icon-plus'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-original-title="Profile settings&quot;" href="/profile" title="Profile settings"><i class='icon-user'></i>
</a></li>
<li>
<a class="has_bottom_tooltip" data-method="delete" data-original-title="Logout" href="/users/sign_out" rel="nofollow" title="Logout"><i class='icon-signout'></i>
</a></li>
<li>
<a class="profile-pic" href="/u/jlw213" id="profile-pic"><img alt="User activity" src="http://www.gravatar.com/avatar/a3d8a0e7d3fa525a5ee4612ae780c77c?s=26&amp;d=mm" />
</a></li>
</ul>
</div>
</div>
</div>
</header>

<script>
  GitLab.GfmAutoComplete.dataSource = "/cs/computer-science-web/autocomplete_sources?type=NilClass&type_id=profile_improvements%2Fnews%2Fviews.py"
  GitLab.GfmAutoComplete.setup();
</script>

<div class='flash-container'>
</div>


<nav class='main-nav navbar-collapse collapse'>
<div class='container'><ul>
<li class="home"><a href="/cs/computer-science-web" title="Project"><i class='icon-home'></i>
</a></li><li class="active"><a href="/cs/computer-science-web/tree/profile_improvements">Files</a>
</li><li class=""><a href="/cs/computer-science-web/commits/profile_improvements">Commits</a>
</li><li class=""><a href="/cs/computer-science-web/network/profile_improvements">Network</a>
</li><li class=""><a href="/cs/computer-science-web/graphs/profile_improvements">Graphs</a>
</li><li class=""><a href="/cs/computer-science-web/issues">Issues
<span class='count issue_counter'>0</span>
</a></li><li class=""><a href="/cs/computer-science-web/merge_requests">Merge Requests
<span class='count merge_counter'>1</span>
</a></li><li class=""><a href="/cs/computer-science-web/wikis/home">Wiki</a>
</li><li class=""><a class="stat-tab tab " href="/cs/computer-science-web/edit">Settings
</a></li></ul>
</div>
</nav>
<div class='container'>
<div class='content'><div class='tree-ref-holder'>
<form accept-charset="UTF-8" action="/cs/computer-science-web/refs/switch" class="project-refs-form" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
<select class="project-refs-select select2 select2-sm" id="ref" name="ref"><optgroup label="Branches"><option value="cms">cms</option>
<option value="development">development</option>
<option value="exch_calendar">exch_calendar</option>
<option value="google_calendar">google_calendar</option>
<option value="landing-page-adjustment">landing-page-adjustment</option>
<option value="master">master</option>
<option value="news">news</option>
<option selected="selected" value="profile_improvements">profile_improvements</option>
<option value="readme">readme</option>
<option value="ui_improvements">ui_improvements</option></optgroup><optgroup label="Tags"></optgroup></select>
<input id="destination" name="destination" type="hidden" value="blob" />
<input id="path" name="path" type="hidden" value="news/views.py" />
</form>


</div>
<div class='tree-holder' id='tree-holder'>
<ul class='breadcrumb'>
<li>
<i class='icon-angle-right'></i>
<a href="/cs/computer-science-web/tree/profile_improvements">computer-science-web
</a></li>
<li>
<a href="/cs/computer-science-web/tree/profile_improvements/news">news</a>
</li>
<li>
<a href="/cs/computer-science-web/blob/profile_improvements/news/views.py"><span class='cblue'>
views.py
</span>
</a></li>
</ul>
<ul class='blob-commit-info bs-callout bs-callout-info'>
<li class='commit js-toggle-container'>
<div class='commit-row-title'>
<a class="commit_short_id" href="/cs/computer-science-web/commit/7bd6659ec19f6831200afc8a6ec5bb33aec6dde5">7bd6659ec</a>
&nbsp;
<span class='str-truncated'>
<a class="commit-row-message" href="/cs/computer-science-web/commit/7bd6659ec19f6831200afc8a6ec5bb33aec6dde5">Extra attachment working</a>
</span>
<a class="pull-right" href="/cs/computer-science-web/tree/7bd6659ec19f6831200afc8a6ec5bb33aec6dde5">Browse Code »</a>
<div class='notes_count'>
</div>
</div>
<div class='commit-row-info'>
<a class="commit-author-link has_tooltip" data-original-title="jaredw@cs.txstate.edu" href="mailto:jaredw@cs.txstate.edu"><img alt="" class="avatar s16" src="http://www.gravatar.com/avatar/317e151a104e397c713348dbff67ee41?s=16&amp;d=mm" width="16" /> <span class="commit-author-name">Jared Wallace</span></a>
<div class='committed_ago'>
<time class='time_ago' data-placement='top' data-toggle='tooltip' datetime='2014-05-21T19:55:46Z' title='May 21, 2014 2:55pm'>2014-05-21 14:55:46 -0500</time>
<script>$('.time_ago').timeago().tooltip()</script>
 &nbsp;
</div>
</div>
</li>

</ul>
<div class='tree-content-holder' id='tree-content-holder'>
<div class='file-holder'>
<div class='file-title'>
<i class='icon-file'></i>
<span class='file_name'>
views.py
<small>6.16 KB</small>
</span>
<span class='options'><div class='btn-group tree-btn-group'>
<a class="btn btn-small" href="/cs/computer-science-web/edit/profile_improvements/news/views.py">edit</a>
<a class="btn btn-small" href="/cs/computer-science-web/raw/profile_improvements/news/views.py" target="_blank">raw</a>
<a class="btn btn-small" href="/cs/computer-science-web/blame/profile_improvements/news/views.py">blame</a>
<a class="btn btn-small" href="/cs/computer-science-web/commits/profile_improvements/news/views.py">history</a>
<a class="remove-blob btn btn-small btn-remove" data-toggle="modal" href="#modal-remove-blob">remove
</a></div>
</span>
</div>
<div class='file-content code'>
<div class='highlighted-data solarized-dark'>
<div class='line-numbers'>
<a href="#L1" id="L1" rel="#L1"><i class='icon-link'></i>
1
</a><a href="#L2" id="L2" rel="#L2"><i class='icon-link'></i>
2
</a><a href="#L3" id="L3" rel="#L3"><i class='icon-link'></i>
3
</a><a href="#L4" id="L4" rel="#L4"><i class='icon-link'></i>
4
</a><a href="#L5" id="L5" rel="#L5"><i class='icon-link'></i>
5
</a><a href="#L6" id="L6" rel="#L6"><i class='icon-link'></i>
6
</a><a href="#L7" id="L7" rel="#L7"><i class='icon-link'></i>
7
</a><a href="#L8" id="L8" rel="#L8"><i class='icon-link'></i>
8
</a><a href="#L9" id="L9" rel="#L9"><i class='icon-link'></i>
9
</a><a href="#L10" id="L10" rel="#L10"><i class='icon-link'></i>
10
</a><a href="#L11" id="L11" rel="#L11"><i class='icon-link'></i>
11
</a><a href="#L12" id="L12" rel="#L12"><i class='icon-link'></i>
12
</a><a href="#L13" id="L13" rel="#L13"><i class='icon-link'></i>
13
</a><a href="#L14" id="L14" rel="#L14"><i class='icon-link'></i>
14
</a><a href="#L15" id="L15" rel="#L15"><i class='icon-link'></i>
15
</a><a href="#L16" id="L16" rel="#L16"><i class='icon-link'></i>
16
</a><a href="#L17" id="L17" rel="#L17"><i class='icon-link'></i>
17
</a><a href="#L18" id="L18" rel="#L18"><i class='icon-link'></i>
18
</a><a href="#L19" id="L19" rel="#L19"><i class='icon-link'></i>
19
</a><a href="#L20" id="L20" rel="#L20"><i class='icon-link'></i>
20
</a><a href="#L21" id="L21" rel="#L21"><i class='icon-link'></i>
21
</a><a href="#L22" id="L22" rel="#L22"><i class='icon-link'></i>
22
</a><a href="#L23" id="L23" rel="#L23"><i class='icon-link'></i>
23
</a><a href="#L24" id="L24" rel="#L24"><i class='icon-link'></i>
24
</a><a href="#L25" id="L25" rel="#L25"><i class='icon-link'></i>
25
</a><a href="#L26" id="L26" rel="#L26"><i class='icon-link'></i>
26
</a><a href="#L27" id="L27" rel="#L27"><i class='icon-link'></i>
27
</a><a href="#L28" id="L28" rel="#L28"><i class='icon-link'></i>
28
</a><a href="#L29" id="L29" rel="#L29"><i class='icon-link'></i>
29
</a><a href="#L30" id="L30" rel="#L30"><i class='icon-link'></i>
30
</a><a href="#L31" id="L31" rel="#L31"><i class='icon-link'></i>
31
</a><a href="#L32" id="L32" rel="#L32"><i class='icon-link'></i>
32
</a><a href="#L33" id="L33" rel="#L33"><i class='icon-link'></i>
33
</a><a href="#L34" id="L34" rel="#L34"><i class='icon-link'></i>
34
</a><a href="#L35" id="L35" rel="#L35"><i class='icon-link'></i>
35
</a><a href="#L36" id="L36" rel="#L36"><i class='icon-link'></i>
36
</a><a href="#L37" id="L37" rel="#L37"><i class='icon-link'></i>
37
</a><a href="#L38" id="L38" rel="#L38"><i class='icon-link'></i>
38
</a><a href="#L39" id="L39" rel="#L39"><i class='icon-link'></i>
39
</a><a href="#L40" id="L40" rel="#L40"><i class='icon-link'></i>
40
</a><a href="#L41" id="L41" rel="#L41"><i class='icon-link'></i>
41
</a><a href="#L42" id="L42" rel="#L42"><i class='icon-link'></i>
42
</a><a href="#L43" id="L43" rel="#L43"><i class='icon-link'></i>
43
</a><a href="#L44" id="L44" rel="#L44"><i class='icon-link'></i>
44
</a><a href="#L45" id="L45" rel="#L45"><i class='icon-link'></i>
45
</a><a href="#L46" id="L46" rel="#L46"><i class='icon-link'></i>
46
</a><a href="#L47" id="L47" rel="#L47"><i class='icon-link'></i>
47
</a><a href="#L48" id="L48" rel="#L48"><i class='icon-link'></i>
48
</a><a href="#L49" id="L49" rel="#L49"><i class='icon-link'></i>
49
</a><a href="#L50" id="L50" rel="#L50"><i class='icon-link'></i>
50
</a><a href="#L51" id="L51" rel="#L51"><i class='icon-link'></i>
51
</a><a href="#L52" id="L52" rel="#L52"><i class='icon-link'></i>
52
</a><a href="#L53" id="L53" rel="#L53"><i class='icon-link'></i>
53
</a><a href="#L54" id="L54" rel="#L54"><i class='icon-link'></i>
54
</a><a href="#L55" id="L55" rel="#L55"><i class='icon-link'></i>
55
</a><a href="#L56" id="L56" rel="#L56"><i class='icon-link'></i>
56
</a><a href="#L57" id="L57" rel="#L57"><i class='icon-link'></i>
57
</a><a href="#L58" id="L58" rel="#L58"><i class='icon-link'></i>
58
</a><a href="#L59" id="L59" rel="#L59"><i class='icon-link'></i>
59
</a><a href="#L60" id="L60" rel="#L60"><i class='icon-link'></i>
60
</a><a href="#L61" id="L61" rel="#L61"><i class='icon-link'></i>
61
</a><a href="#L62" id="L62" rel="#L62"><i class='icon-link'></i>
62
</a><a href="#L63" id="L63" rel="#L63"><i class='icon-link'></i>
63
</a><a href="#L64" id="L64" rel="#L64"><i class='icon-link'></i>
64
</a><a href="#L65" id="L65" rel="#L65"><i class='icon-link'></i>
65
</a><a href="#L66" id="L66" rel="#L66"><i class='icon-link'></i>
66
</a><a href="#L67" id="L67" rel="#L67"><i class='icon-link'></i>
67
</a><a href="#L68" id="L68" rel="#L68"><i class='icon-link'></i>
68
</a><a href="#L69" id="L69" rel="#L69"><i class='icon-link'></i>
69
</a><a href="#L70" id="L70" rel="#L70"><i class='icon-link'></i>
70
</a><a href="#L71" id="L71" rel="#L71"><i class='icon-link'></i>
71
</a><a href="#L72" id="L72" rel="#L72"><i class='icon-link'></i>
72
</a><a href="#L73" id="L73" rel="#L73"><i class='icon-link'></i>
73
</a><a href="#L74" id="L74" rel="#L74"><i class='icon-link'></i>
74
</a><a href="#L75" id="L75" rel="#L75"><i class='icon-link'></i>
75
</a><a href="#L76" id="L76" rel="#L76"><i class='icon-link'></i>
76
</a><a href="#L77" id="L77" rel="#L77"><i class='icon-link'></i>
77
</a><a href="#L78" id="L78" rel="#L78"><i class='icon-link'></i>
78
</a><a href="#L79" id="L79" rel="#L79"><i class='icon-link'></i>
79
</a><a href="#L80" id="L80" rel="#L80"><i class='icon-link'></i>
80
</a><a href="#L81" id="L81" rel="#L81"><i class='icon-link'></i>
81
</a><a href="#L82" id="L82" rel="#L82"><i class='icon-link'></i>
82
</a><a href="#L83" id="L83" rel="#L83"><i class='icon-link'></i>
83
</a><a href="#L84" id="L84" rel="#L84"><i class='icon-link'></i>
84
</a><a href="#L85" id="L85" rel="#L85"><i class='icon-link'></i>
85
</a><a href="#L86" id="L86" rel="#L86"><i class='icon-link'></i>
86
</a><a href="#L87" id="L87" rel="#L87"><i class='icon-link'></i>
87
</a><a href="#L88" id="L88" rel="#L88"><i class='icon-link'></i>
88
</a><a href="#L89" id="L89" rel="#L89"><i class='icon-link'></i>
89
</a><a href="#L90" id="L90" rel="#L90"><i class='icon-link'></i>
90
</a><a href="#L91" id="L91" rel="#L91"><i class='icon-link'></i>
91
</a><a href="#L92" id="L92" rel="#L92"><i class='icon-link'></i>
92
</a><a href="#L93" id="L93" rel="#L93"><i class='icon-link'></i>
93
</a><a href="#L94" id="L94" rel="#L94"><i class='icon-link'></i>
94
</a><a href="#L95" id="L95" rel="#L95"><i class='icon-link'></i>
95
</a><a href="#L96" id="L96" rel="#L96"><i class='icon-link'></i>
96
</a><a href="#L97" id="L97" rel="#L97"><i class='icon-link'></i>
97
</a><a href="#L98" id="L98" rel="#L98"><i class='icon-link'></i>
98
</a><a href="#L99" id="L99" rel="#L99"><i class='icon-link'></i>
99
</a><a href="#L100" id="L100" rel="#L100"><i class='icon-link'></i>
100
</a><a href="#L101" id="L101" rel="#L101"><i class='icon-link'></i>
101
</a><a href="#L102" id="L102" rel="#L102"><i class='icon-link'></i>
102
</a><a href="#L103" id="L103" rel="#L103"><i class='icon-link'></i>
103
</a><a href="#L104" id="L104" rel="#L104"><i class='icon-link'></i>
104
</a><a href="#L105" id="L105" rel="#L105"><i class='icon-link'></i>
105
</a><a href="#L106" id="L106" rel="#L106"><i class='icon-link'></i>
106
</a><a href="#L107" id="L107" rel="#L107"><i class='icon-link'></i>
107
</a><a href="#L108" id="L108" rel="#L108"><i class='icon-link'></i>
108
</a><a href="#L109" id="L109" rel="#L109"><i class='icon-link'></i>
109
</a><a href="#L110" id="L110" rel="#L110"><i class='icon-link'></i>
110
</a><a href="#L111" id="L111" rel="#L111"><i class='icon-link'></i>
111
</a><a href="#L112" id="L112" rel="#L112"><i class='icon-link'></i>
112
</a><a href="#L113" id="L113" rel="#L113"><i class='icon-link'></i>
113
</a><a href="#L114" id="L114" rel="#L114"><i class='icon-link'></i>
114
</a><a href="#L115" id="L115" rel="#L115"><i class='icon-link'></i>
115
</a><a href="#L116" id="L116" rel="#L116"><i class='icon-link'></i>
116
</a><a href="#L117" id="L117" rel="#L117"><i class='icon-link'></i>
117
</a><a href="#L118" id="L118" rel="#L118"><i class='icon-link'></i>
118
</a><a href="#L119" id="L119" rel="#L119"><i class='icon-link'></i>
119
</a><a href="#L120" id="L120" rel="#L120"><i class='icon-link'></i>
120
</a><a href="#L121" id="L121" rel="#L121"><i class='icon-link'></i>
121
</a><a href="#L122" id="L122" rel="#L122"><i class='icon-link'></i>
122
</a><a href="#L123" id="L123" rel="#L123"><i class='icon-link'></i>
123
</a><a href="#L124" id="L124" rel="#L124"><i class='icon-link'></i>
124
</a><a href="#L125" id="L125" rel="#L125"><i class='icon-link'></i>
125
</a><a href="#L126" id="L126" rel="#L126"><i class='icon-link'></i>
126
</a><a href="#L127" id="L127" rel="#L127"><i class='icon-link'></i>
127
</a><a href="#L128" id="L128" rel="#L128"><i class='icon-link'></i>
128
</a><a href="#L129" id="L129" rel="#L129"><i class='icon-link'></i>
129
</a><a href="#L130" id="L130" rel="#L130"><i class='icon-link'></i>
130
</a><a href="#L131" id="L131" rel="#L131"><i class='icon-link'></i>
131
</a><a href="#L132" id="L132" rel="#L132"><i class='icon-link'></i>
132
</a><a href="#L133" id="L133" rel="#L133"><i class='icon-link'></i>
133
</a><a href="#L134" id="L134" rel="#L134"><i class='icon-link'></i>
134
</a><a href="#L135" id="L135" rel="#L135"><i class='icon-link'></i>
135
</a><a href="#L136" id="L136" rel="#L136"><i class='icon-link'></i>
136
</a><a href="#L137" id="L137" rel="#L137"><i class='icon-link'></i>
137
</a><a href="#L138" id="L138" rel="#L138"><i class='icon-link'></i>
138
</a><a href="#L139" id="L139" rel="#L139"><i class='icon-link'></i>
139
</a><a href="#L140" id="L140" rel="#L140"><i class='icon-link'></i>
140
</a><a href="#L141" id="L141" rel="#L141"><i class='icon-link'></i>
141
</a><a href="#L142" id="L142" rel="#L142"><i class='icon-link'></i>
142
</a><a href="#L143" id="L143" rel="#L143"><i class='icon-link'></i>
143
</a><a href="#L144" id="L144" rel="#L144"><i class='icon-link'></i>
144
</a><a href="#L145" id="L145" rel="#L145"><i class='icon-link'></i>
145
</a><a href="#L146" id="L146" rel="#L146"><i class='icon-link'></i>
146
</a><a href="#L147" id="L147" rel="#L147"><i class='icon-link'></i>
147
</a><a href="#L148" id="L148" rel="#L148"><i class='icon-link'></i>
148
</a><a href="#L149" id="L149" rel="#L149"><i class='icon-link'></i>
149
</a><a href="#L150" id="L150" rel="#L150"><i class='icon-link'></i>
150
</a><a href="#L151" id="L151" rel="#L151"><i class='icon-link'></i>
151
</a><a href="#L152" id="L152" rel="#L152"><i class='icon-link'></i>
152
</a><a href="#L153" id="L153" rel="#L153"><i class='icon-link'></i>
153
</a><a href="#L154" id="L154" rel="#L154"><i class='icon-link'></i>
154
</a><a href="#L155" id="L155" rel="#L155"><i class='icon-link'></i>
155
</a><a href="#L156" id="L156" rel="#L156"><i class='icon-link'></i>
156
</a><a href="#L157" id="L157" rel="#L157"><i class='icon-link'></i>
157
</a><a href="#L158" id="L158" rel="#L158"><i class='icon-link'></i>
158
</a><a href="#L159" id="L159" rel="#L159"><i class='icon-link'></i>
159
</a><a href="#L160" id="L160" rel="#L160"><i class='icon-link'></i>
160
</a><a href="#L161" id="L161" rel="#L161"><i class='icon-link'></i>
161
</a><a href="#L162" id="L162" rel="#L162"><i class='icon-link'></i>
162
</a><a href="#L163" id="L163" rel="#L163"><i class='icon-link'></i>
163
</a><a href="#L164" id="L164" rel="#L164"><i class='icon-link'></i>
164
</a><a href="#L165" id="L165" rel="#L165"><i class='icon-link'></i>
165
</a><a href="#L166" id="L166" rel="#L166"><i class='icon-link'></i>
166
</a><a href="#L167" id="L167" rel="#L167"><i class='icon-link'></i>
167
</a><a href="#L168" id="L168" rel="#L168"><i class='icon-link'></i>
168
</a><a href="#L169" id="L169" rel="#L169"><i class='icon-link'></i>
169
</a><a href="#L170" id="L170" rel="#L170"><i class='icon-link'></i>
170
</a><a href="#L171" id="L171" rel="#L171"><i class='icon-link'></i>
171
</a><a href="#L172" id="L172" rel="#L172"><i class='icon-link'></i>
172
</a><a href="#L173" id="L173" rel="#L173"><i class='icon-link'></i>
173
</a><a href="#L174" id="L174" rel="#L174"><i class='icon-link'></i>
174
</a><a href="#L175" id="L175" rel="#L175"><i class='icon-link'></i>
175
</a><a href="#L176" id="L176" rel="#L176"><i class='icon-link'></i>
176
</a><a href="#L177" id="L177" rel="#L177"><i class='icon-link'></i>
177
</a><a href="#L178" id="L178" rel="#L178"><i class='icon-link'></i>
178
</a><a href="#L179" id="L179" rel="#L179"><i class='icon-link'></i>
179
</a></div>
<div class='highlight'>
<pre><code>from news.models import Post, get_posts
from news.forms import PostForm, EmailForm
from cms.PageHelper import get_top_nav_list
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import Http404, HttpResponseRedirect
from django.core.urlresolvers import reverse, reverse_lazy
from django.core.mail import EmailMultiAlternatives
from django.contrib.auth.models import User
from django.utils.html import strip_tags

def add_post(request):
    if request.method == 'POST':
        form = PostForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/news/view_all/')
        else:
            print form.errors
    else:
        form = PostForm()
    posts = get_posts()
    return render_to_response(
        'news/add_post.html',
        {
            'posts': posts,
            'request': request,
            'form': form,
            'top_nav_list': get_top_nav_list(),
        },
        RequestContext(request)
    )

def email_announcement(request, id):
    try:
        post = Post.objects.get(pk=id)
    except:
        raise Http404

    if request.method == 'POST':
        form = EmailForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            subject = form.cleaned_data['subject']
            recipients = get_aliases(form.cleaned_data['sendto'], form.cleaned_data['additional_sendto'])
            message = form.cleaned_data['message']
            from_email = &quot;news@cs.txstate.edu&quot;
            # Remove html formatting
            text_message = strip_tags(message)
            email = EmailMultiAlternatives(
                    subject=subject,
                    body=text_message,
                    from_email=from_email,
                    bcc=recipients
            )
            # We want to send both plaintext and html
            email.attach_alternative(message, &quot;text/html&quot;)
            # grab the file already associated with the post and attach it
            if post.attachment:
                attachment = post.attachment.path
                email.attach_file(attachment)
            # If the user wanted another file as well (from the email form)
            if request.FILES['attachment']:
                attachment = request.FILES['attachment']
                email.attach(attachment.name, attachment.read(), attachment.content_type)
            email.send()
            return render_to_response(
                'news/email_sent.html',
                {
                    'post': post,
                    'top_nav_list': get_top_nav_list(),
                },
                RequestContext(request)
            )
        else:
            print form.errors
    else:
        form = EmailForm(initial={
            'subject': post.heading,
            'message': post.body,
            # we slice off the path so only the filename remains
            'attachment_default': post.attachment.name[5:],
            }
        )
    return render_to_response(
            'news/send_email.html',
            {
                'form': form,
                'top_nav_list': get_top_nav_list(),
            },
            RequestContext(request)
    )

def get_aliases(sendto, additional):
    recipients = []
    users = User.objects.all()
    # We use a series of elif to avoid double emailing people who match
    # on more than one query
    for user in users:
        groups = user.groups.all()
        if user.attends.filter(course__number='1428') and '1428' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number='1319') and '1319' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__gt='1000') and 'fish' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__gt='2000') and 'soph' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__gt='3000') and 'junr' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__gt='4000') and 'senr' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__lt='5000') and 'unde' in sendto:
            recipients.append(user.email)
        elif user.attends.filter(course__number__gt='5000') and 'grad' in sendto:
            recipients.append(user.email)
        elif 'falc' in sendto:
            recipients.append('faculty@cs.txstate.edu')
        elif 'extf' in sendto:
            recipients.append('extd-faculty@cs.txstate.edu')
        elif 'coll' in sendto:
            recipients.append('colleagues@cs.txstate.edu')
        elif 'iabm' in sendto:
            recipients.append('iab@cs.txstate.edu')
        elif 'webd' in sendto:
            recipients.append('infra@cs.txstate.edu')
    for email in additional:
        recipients.append(email)
    return recipients

def detail(request, id):
    try:
        post = Post.objects.get(pk=id,)
    except:
        raise Http404
    return render_to_response(
        'news/detail.html',
        {
            'post':post,
            'top_nav_list': get_top_nav_list(),
        },
        RequestContext(request),
    )

def view_all(request):
    posts = get_posts()
    return render_to_response(
        'news/view_all.html',
        {
            'posts':posts,
            'request': request,
            'top_nav_list': get_top_nav_list(),
        },
        RequestContext(request),
    )

def edit_post(request, id):
    try:
        post = Post.objects.get(pk=id)
    except:
        raise Http404
    #if not request.user.is_staff:
    #    return render(request, 'news/permission_denied.html')
    if request.method == 'POST':
        form = PostForm(data=request.POST, files=request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('news:detail', kwargs={'id':id}))
    else:
        form = PostForm(instance=post)
    return render_to_response(
        'news/edit_post.html',
        {
            'form': form,
            'post': post,
            'top_nav_list': get_top_nav_list(),
        },
        RequestContext(request)
    )</code></pre>
</div>
</div>

</div>

</div>
</div>

</div>
<div class='modal hide' id='modal-remove-blob'>
<div class='modal-dialog'>
<div class='modal-content'>
<div class='modal-header'>
<a class='close' data-dismiss='modal' href='#'>×</a>
<h3 class='page-title'>Remove views.py</h3>
<p class='light'>
From branch
<strong>profile_improvements</strong>
</p>
</div>
<div class='modal-body'>
<form accept-charset="UTF-8" action="/cs/computer-science-web/blob/profile_improvements/news/views.py" class="form-horizontal" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="_method" type="hidden" value="delete" /><input name="authenticity_token" type="hidden" value="xVN+NuZzUFfTo5oDpkGPPpvr8Wns4r3eOcouRDJ15C4=" /></div>
<div class='form-group commit_message-group'>
<label class="control-label" for="commit_message">Commit message
</label><div class='col-sm-10'>
<textarea class="form-control" id="commit_message" name="commit_message" placeholder="Removed this file because..." required="required" rows="3">
</textarea>
</div>
</div>
<div class='form-group'>
<div class='col-sm-2'></div>
<div class='col-sm-10'>
<input class="btn btn-remove" name="commit" type="submit" value="Remove file" />
<a class="btn btn-cancel" data-dismiss="modal" href="#">Cancel</a>
</div>
</div>
</form>

</div>
</div>
</div>
</div>

</div>
</div>
</body>
</html>
