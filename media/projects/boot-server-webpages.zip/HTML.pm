#!/bin/usr/Perl
use strict;
use warnings;
use Authentication;
package HTML;


#========================================================================================================
# Prints the Web Page Headers
#========================================================================================================
sub headers
{
my ($title) = @_;
return <<EOF;
<!doctype html>
<html>
<head>
<title>$title</title>
</head>
<body>
EOF

}

#========================================================================================================
# Prints the Host Submission Table
#========================================================================================================
sub form
{
my ($db,$loc,$mod,$os) = @_;
print <<EOF;

<form id="form1" name="form1" method="post" action="">
  <table align = "center">
    <tr>
      <td><div align="right">Hostname:</div></td>
      <td><label for="hostname"></label>
	<div align="right">
	  <input type="text" name="hostname">
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Ticket #:</div></td>
      <td><label for="Ticket"></label>
	<div align="right">
	  <select name="ticket">
EOF

foreach my $row (@$db)
{
 print "\t\t\t<option value=\"".$row->{"Ticket"}."\">".$row->{"Ticket"}."</option>\n";
}
print <<EOF;
	  </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Location:</div></td>
      <td><label for="Location"></label>
	<div align="right">
	  <select name="location">
EOF
		
foreach (@$loc)
{
 print "\t\t\t<option value=\"".$_."\">".$_."</option>\n";
}
print <<EOF;
	  </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Model:</div></td>
      <td><label for="Model"></label>
	<div align="right">
	  <select name="model">
EOF

foreach (@$mod)
{
  print "\t\t\t<option value=\"".$_."\">".$_."</option>\n";
}
print <<EOF;
	  </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Default OS:</div></td>
      <td><label for="Default OS"></label>
        <div align="right">
          <select name="defaultOs">
EOF

foreach (@$os)
{	
  print "\t\t\t<option value=\"".$_."\">".$_."</option>\n";
}
print <<EOF;    
          </select>
      </div></td>
    </tr>
  </table>
      <table align = "center">
      <tr>
	<td><input type="submit" name="Action" value="Submit" /></td>
	<td><input type="submit" name="logout" value="Logout" /></td>
      </tr>
  </table>
</form>
</body>
</html>
EOF


}
#========================================================================================================


#========================================================================================================
# Returns the approval message as a string
#========================================================================================================
sub approveSuccess
{
   my ($netid,$host) = @_;
return <<END_OF_APPROVE;
<table align ="center">
<tr>
  <td style="text-align:center"><h3>The host $host was approved. An email was just sent to <a href="mailto:$netid\@txstate.edu">$netid\@txstate.edu</a> informing him/her that his/her submission was approved.</h2></td>
</tr>
<tr>
  <td style="text-align:center"><h4>You will be redirected back to this page in 5 seconds</h3></td>
</tr>
</table>
<script type="text/javascript">
window.setTimeout(function(){window.location.reload(true);},5000);
</script>
END_OF_APPROVE
}
#========================================================================================================

#========================================================================================================
# Returns the denial message as a string
#========================================================================================================
sub denySuccess
{
   my ($netid,$host) = @_;
return <<END_OF_APPROVE;
<table align ="center">
<tr>
  <td style="text-align:center"><h3>The host $host was denied. An email was just sent to <a href="mailto:$netid\@txstate.edu">$netid\@txstate.edu</a> to inform him/her that his/her submission was denied.</h2></td>
</tr>
<tr>
  <td style="text-align:center"><h4>You will be redirected back to this page in 5 seconds</h3></td>
</tr>
</table>
<script type="text/javascript">
window.setTimeout(function(){window.location.reload(true);},5000);
</script>
END_OF_APPROVE
}
#========================================================================================================

#========================================================================================================
# Returns the standard authentication form as a string
#========================================================================================================
sub _authForm
{
        return <<END_OF_AUTH_FORM;
<form method="POST">
<table align="center">
 <tr>
  <td class="name">NetID:</td>
  <td class="value"><input type="text" name="username" class="input" id="username"></td>
 </tr>
 <tr>
  <td class="name">Password:</td>
  <td class="value"><input type="password" name="password" class="input"></td>
 </tr>
 <tr>
  <td colspan="2" style="text-align:center">
   <input type="submit" value="Login" class="button">
  </td>
 </tr>
</table>
<script type="text/javascript">
window.onload=function()
{
        document.getElementById("username").focus();
}
</script>
</form>
END_OF_AUTH_FORM
}
#========================================================================================================


#========================================================================================================
# Returns the No Current Ticket form as a string
#========================================================================================================
sub noTickets
{
	return <<END_OF_HTML
<form method="POST">
<table align ="center">
 <tr>
  <td><h3>There are currently no computers that have been flagged for NetBooting.</h2></td>
 </tr>
 <tr>
  <td><h4>If you have received a ticket number please contact the <a href="mailto:infra\@cs.txstate.edu">Computer Science Infrastructure Team</a>
 <tr>
  <td style="text-align:center"><input type ="submit" name="logout" value="Logout"/></td>
 </tr>
</table>
</form>
END_OF_HTML
}
#========================================================================================================


#========================================================================================================
# Returns the No Current Ticket Admin form as a string
#========================================================================================================
sub noAdminTickets
{
        return <<END_OF_HTML
<form method="POST">
<table align ="center">
 <tr>
  <td><h3>There are currently no computers that have been submitted for approval.</h2></td>
 </tr>
</table>
</form>
END_OF_HTML
}
#========================================================================================================


#========================================================================================================
# Returns the successful registration message
#========================================================================================================
sub successfulRegister
{
return <<EOF
<table align="center">
<tr>
<td style="text-align:center"><h3>You have successfull registered your computer. The NetBoot Admins will review it and you will be notified by email when it has been approved.</h2></td>
</tr>
<tr>
<td style="text-align:center"><h4>You will be redirected back to the NetBoot Registration form in 5 seconds.</h3></td>
</tr>
</table>
<script type="text/javascript">
window.setTimeout(function(){window.location.reload(true);},5000);
</script>

EOF
}
#========================================================================================================

#========================================================================================================
# Returns the admin form view as a string
#========================================================================================================
sub adminForm
{
        my ($db)=@_;
        print <<END_OF_ADMIN;
<form method="post">
<table align="center">
  <tr>
   <td><h2>Admin Panel</h2></td>
</table>
<table align ="center">
 <tr>
  <td>Ticket:</td>
  <td><label for="TicketA"></label>
   <div align="right">
   <select name="ticketa">
END_OF_ADMIN

foreach my $row (@$db)
{
 print "\t<option value=\"".$row->{"Ticket"}."\">".$row->{"Ticket"}."</option>\n";
}

print <<END_OF_ADMIN;
          </select>
      </div></td>

  <td style="text-align:center">
   <input type="submit" name="Approve" value="Approve">
  </td>
  <td style="text-align:center">
   <input type="submit" name="Decline" value="Decline">
  </td>
</tr>
</table>
<br><br>
<table border="1" align="center" cellpadding="2" cellspacing="2">
  <tr>
   <td>Ticket</td>
   <td>Hostname</td>
   <td>DefaultOS</td>
   <td>Model</td>
   <td>Room</td>
   <td>MacAddr</td>

END_OF_ADMIN

foreach my $row (@$db)
{
print <<END_OF_ROW;
  <tr>
   <td>$row->{"Ticket"}</td>
   <td>$row->{"Hostname"}</td>
   <td>$row->{"DefaultOS"}</td>
   <td>$row->{"Model"}</td>
   <td>$row->{"Room"}</td>
   <td>$row->{"Mac"}</td>
  </tr>
END_OF_ROW
}

}
#========================================================================================================


#========================================================================================================
#Returns the duplicate host error message as a string
#========================================================================================================
sub dupHost
{
   my  ($netid,$host) = @_;
return <<END_OF_DUP;
<table align ="center">
<tr>
<td style="text-align:center"><h3>A computer with the name $host already exists in the Host Table</h2></td>
</tr>
END_OF_DUP
}
#========================================================================================================


#========================================================================================================
# Returns the FIRST authentication form as a string
#========================================================================================================
sub FirstAuth
{
	return <<END_OF_AUTH_HEADER . "\r\n" . &_authForm();
<table align="center">
<tr>
<td style="text-align:center"><h2>Welcome to the Texas State Department of Computer Science NetBoot Registration System </h2></td>
</tr>
<tr>
<td style="text-align:center"><h3>Login to finish the registration process or follow this <a href="link">link</a> for help</h3></td>
</tr>
</table>
END_OF_AUTH_HEADER
}
#========================================================================================================


#========================================================================================================
# Prints the FAILED/INVALID authentication form
#========================================================================================================
sub InvalidAuth
{
	return <<END_OF_AUTH_HEADER . "\r\n" . &_authForm();
 <center><h3>Invalid Username or Password</h3>
 <p>The NetID or password you have used is invalid. Please try again.</p></center>
END_OF_AUTH_HEADER
}
#========================================================================================================


#========================================================================================================
# Prints the FAILED/INVALID authentication form
#========================================================================================================
sub LogoutAuth
{
	return <<END_OF_AUTH_HEADER . "\r\n" . &_authForm();
<center> <p>You have been successfully logged out. You will have to login again to access the NetBoot Registration.</p>
 <hr>

 <h1>Authentication Needed</h1></center>
END_OF_AUTH_HEADER
}

sub Footer
{
	my $timeoutMinutes=Authentication::getTimeout();

	return <<END_OF_HTML_FOOTER;
<script type="text/javascript">
var secondsLeft=60 * $timeoutMinutes;
function countdown()
{
	window.setTimeout(countdown, 500);
}

window.setTimeout(countdown, 500);
</script>
</body>
</html>
END_OF_HTML_FOOTER
}
#========================================================================================================

1;

