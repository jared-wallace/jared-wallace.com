#!/usr/bin/perl
use strict;
use warnings;

use DBI;
use CGI;
use CGI::Carp qw(fatalsToBrowser carpout);
use HTML;
use Authentication;
#=========================================================================================================
# Constants
#=========================================================================================================
use constant PXE_ADMINS  => qw(ar1666 1 mme1 1 jlw213 1 jr63 1 tnm2 1);
use constant LOC  	 => ["Derr 231A", "Derr 231B", "Derr 231C", "Derr 231M", "Derr 236", 
					"Derr 325","MCS 591", "MCS 592", "MCS 593", "MCS 594", "Office"];
use constant MODEL 	 => ["Optiplex 745", "Optiplex 755", "Optiplex 780", 
					"Optiplex 990", "Optiplex 9010", "Laptop", "Other"];
use constant DEFAULT_OS  => ["centOS","linux", "windows", "hdd"];
use constant DATABASE    => DBI->connect("DBI:mysql:HostTable:host=localhost:3306", 
						"root", "***removed***");
use constant ADOU 	 => (
	"Derr 231A" => "OU=DERR 231,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"Derr 231B" => "OU=DERR 231,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"Derr 231C" => "OU=DERR 231C,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"Derr 231M" => "OU=DERR 231,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"Derr 236"  => "OU=DERR 236,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"Derr 325"  => "OU=DERR 325,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
	"MCS 591"   => "OU=Eye Tracking, OU=MCS 590,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
        "MCS 592"   => "OU=Open, OU=MCS 590,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
        "MCS 593"   => "OU=Tutoring, OU=MCS 590,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
        "MCS 594"   => "OU=Exe Lounge, OU=MCS 590,OU=Labs,OU=Computers,
				OU=CS,OU=COSE,OU=AA,DC=matrix,DC=txstate,DC=edu",
			     );
#========================================================================================================
my ($netid, $request);
$request=CGI->new();
#========================================================================================================
# Make sure the user is properly authenticated
#========================================================================================================
{
   my ($auth, $time, $token);
   ($netid, $time, $token)=($request->cookie('netid'), $request->cookie('authTime'), 
					$request->cookie('authToken'));

   $auth=Authentication->new();
 
   #-----------------------------------------------------------------------------------------------------
   # First attempt to validate any token that the user may have sent us
   #-----------------------------------------------------------------------------------------------------
   ($netid, $time, $token)=$auth->validateToken($netid, $time, $token);
   if(! defined($netid))		# If the token is INVALID (either forged or not authenticated) 
   {
   	my ($username, $password)=($request->param('username'), $request->param('password'));
   	#----------------------------------------------------------------------------------------
	# The token is invalid. They could be logging in for the first time. If they have submitted
	#	credentials to be validated, then show them the first login form.
	#------------------------------------------------------------------------------------------------
	if( !defined($username) || !defined($password) || $username eq "" || $password eq "")
	{
		# MISSING USERNAME AND PASSWORD
		print $request->header();
		print HTML::headers("Authentication Needed");
		print HTML::FirstAuth();
		print HTML::Footer();
		exit 0;
	}
	#------------------------------------------------------------------------------------------------

	#------------------------------------------------------------------------------------------------
	# They have submitted credentials for validation, attempt to create a token for them. If
	#	it fails creating a token, then show them the invalid login form.
	#------------------------------------------------------------------------------------------------
	($netid, $time, $token)=$auth->createToken($username, $password); $username=""; $password="";
	if(! defined($netid))
	{
		# INVALID USERNAME OR PASSWORD
		print $request->header();
		print HTML::headers("Authentication Needed");
		print HTML::InvalidAuth();
		print HTML::Footer();
		exit 0;
	}
	#------------------------------------------------------------------------------------------------
   }
#--------------------------------------------------------------------------------------------------------


#--------------------------------------------------------------------------------------------------------
# NetID was defined and we are successfully authenticated. Now use CGI to send a cookie to persist
#	these values so the browser sends them back everytime.
# However, if the user is logging out, then we blank out the 3 authentication values BEFORE the
#	cookie is sent so that the page thinks your unauthenticated.
#--------------------------------------------------------------------------------------------------------
($netid, $time, $token)=("","","") if(defined($request->param('logout'))
							 && $request->param('logout') eq "Logout");
my $cookie="";
print "Set-Cookie: " . ($cookie=CGI::Cookie->new(-name=>'netid',-value=>$netid,
			-expires=>"+" . $auth->getTimeout() . "m")) . "\r\n";
print "Set-Cookie: " . ($cookie=CGI::Cookie->new(-name=>'authTime',-value=>$time,
			-expires=>"+" . $auth->getTimeout() . "m")) . "\r\n";
print "Set-Cookie: " . ($cookie=CGI::Cookie->new(-name=>'authToken',-value=>$token,
			-expires=>"+" . $auth->getTimeout() . "m")) . "\r\n";
#--------------------------------------------------------------------------------------------------------

#--------------------------------------------------------------------------------------------------------
# If they've logged out, show them the login page.
#--------------------------------------------------------------------------------------------------------
if($netid eq "")
{
	print $request->header();
	print HTML::headers("Logged Out");
	print HTML::LogoutAuth();
	print HTML::Footer();
	exit 0;
}
#--------------------------------------------------------------------------------------------------------
}

#========================================================================================================
# Receive and SQL inject escape data from form
#========================================================================================================
my ($host,$ticket,$location,$mod,$dOS,$action,$isAdmin);
print $request->header();
$host = escapeSql($request->param("hostname")) || "";
$ticket = escapeSql($request->param("ticket")) || "";
$location = escapeSql($request->param("location")) || "";
$dOS = escapeSql($request->param("defaultOs")) || "";
$mod = escapeSql($request->param("model")) || "";
$action = $request->param("Action") || "";
#========================================================================================================


#========================================================================================================
# Check to see if user is an admin
#========================================================================================================
my (%admins)=(PXE_ADMINS);
$isAdmin=exists($admins{$netid});
#========================================================================================================

#========================================================================================================
# Database Query to gather the Tickets from the Error Table. Tickets correspond with Mac Addr.
#--------------------------------------------------------------------------------------------------------
# This queries the database for every instance where the Done column is No. Once a Ticket has been 
# submitted for review this column is changed to Pending. Once it has been approved by Admin it is then
# changed to Yes.
#--------------------------------------------------------------------------------------------------------
#========================================================================================================
my $answer = executeSql(DATABASE,"SELECT Ticket FROM error WHERE Done = 'No'");
#========================================================================================================


#========================================================================================================
# Print the NetBoot Registration form for all authenticated users
#========================================================================================================
{
   #--------------------------------------------------------
   #No button has been pushed and the query returned nothing
   #--------------------------------------------------------
   if($action eq "" && $#{$answer} == -1 )
   {
 	print HTML::noTickets();
   }
   #--------------------------------------------------------
   #No button pushed but the query did return something
   #--------------------------------------------------------
   elsif($action eq "")
   {
       print HTML::headers("NetBoot Registration");
       HTML::form($answer,LOC,MODEL,DEFAULT_OS);
   }
   #--------------------------------------------------------
   #An empty hostname was submitted
   #--------------------------------------------------------
   elsif($host eq "")
   {
       print HTML::headers("NetBoot Registration");
       print "<h1>You can not submit a computer without a hostname.</h1><br>";
       HTML::form($answer,LOC,MODEL,DEFAULT_OS);
   }
   #--------------------------------------------------------
   #All fields where properly defined. Data submitted
   #--------------------------------------------------------
   else
   {
       &executeSql(DATABASE,"UPDATE error Set Hostname='$host', Done='Pending',Model='$mod',
		Room='$location', NetID='$netid',DefaultOS='$dOS' WHERE Ticket=$ticket");
       print HTML::headers("NetBoot Registration");
       print HTML::successfulRegister();
   }
}
#========================================================================================================


#========================================================================================================
# If the user is an Admin then display Admin Approval Page
#========================================================================================================
if($isAdmin)
{
   #--------------------------------------------------------
   # Retrieve the data from the Admin form. $ticketA is the
   # approved ticket number
   #--------------------------------------------------------
   my $ticketA = escapeSql($request->param("ticketa")) || "";

   #--------------------------------------------------------
   # Retrieve the information about the ticket from the DB
   #--------------------------------------------------------
   my $ans= executeSql(DATABASE,"SELECT * FROM error WHERE Ticket='$ticketA'");

   #--------------------------------------------------------
   # If an admin button was selected
   #--------------------------------------------------------
   if($ticketA ne "")
   {
        #--------------------------------------------------------------
        # Retrieve values from selected admin button (Approve,Decline)
        #--------------------------------------------------------------
	my $approve = $request->param("Approve");
	my $decline = $request->param("Decline");

        #--------------------------------------------------------
        # If approve was selected
        #--------------------------------------------------------
	if($approve ne "")
	{
		approveHost($ticketA,$ans,ADOU);

	}

	#--------------------------------------------------------
	# If decline was selected
	#--------------------------------------------------------
	if($decline ne "")
	{
		declineHost($ticketA,$ans);
	}
	
   }

   #--------------------------------------------------------
   # Select All pending requests
   #--------------------------------------------------------
   my $answer = executeSql(DATABASE,"SELECT * FROM error WHERE Done = 'Pending'");

   #--------------------------------------------------------
   # There are no tickets to be approved.
   #--------------------------------------------------------
   if($#{$answer} == -1 )
   {
       print HTML::noAdminTickets();
   }
   #--------------------------------------------------------
   # Print the admin form.
   #--------------------------------------------------------
   else
   {
      HTML::adminForm($answer);
   }
}
#========================================================================================================

#=======================================================================================================#
# 						Functions						#
#=======================================================================================================#

#========================================================================================================
# approveHost(Ticket of Approved Host, Database Handle of Approved Ticket, Active Directory Constant)
#--------------------------------------------------------------------------------------------------------
# This function is called when a host is approved. It first checks to see if then Hostname already exists
# in the table. If a duplicate does exist it it declines the host, deletes it from the table, then sends 
# email to the requestee that the host was declined. If the host is accepted it adds it to table and sends
# email to the requestee that the host was approved.
#========================================================================================================
sub approveHost
{
   my ($appHost,$ans,%ad) =  @_;
   my $dupTest = executeSql(DATABASE,"SELECT * from hosts 
	WHERE Hostname='$ans->[0]->{'Hostname'}.cs.txstate.edu'");

   #--------------------------------------------------------
   # Checks for duplicates. Denies them if any exist. 
   # declineHost() handles the email
   #--------------------------------------------------------
   if($#{$dupTest} != -1 )
   {
	print HTML::dupHost($ans->[0]->{'NetID'},$ans->[0]->{'Hostname'});
	declineHost($ans->[0]->{'Ticket'},$ans);
	exit 0;
   }
   #--------------------------------------------------------
   # Insert into Database and emails the requestee
   #--------------------------------------------------------
   else
   {
      executeSql(DATABASE,"INSERT into hosts(Hostname, Mac, Model, Room, DefaultOS, ADOU) VALUES
          ('$ans->[0]->{'Hostname'}.cs.txstate.edu','$ans->[0]->{'Mac'}','$ans->[0]->{'Model'}',
             '$ans->[0]->{'Room'}','$ans->[0]->{'DefaultOS'}','$ad{$ans->[0]->{'Room'}}')");

      executeSql(DATABASE,"UPDATE error SET Done='Yes' WHERE Ticket='$appHost'");
		
	print HTML::approveSuccess($ans->[0]->{'NetID'},$ans->[0]->{'Hostname'});
	emailSomeone($ans->[0]->{'NetID'},$ans->[0]->{'Hostname'},"approved");
	exit 0;
   }

}
#========================================================================================================

#========================================================================================================
# declineHost(Ticket of Declined Host, Database Handle of Approved Ticket)
#--------------------------------------------------------------------------------------------------------
# This function deletes the declined Host from the Host Table, prints the denial HTML to the Admin Panel,
# then emails the requestee informing them of the denial.
#========================================================================================================
sub declineHost
{
      my ($ticket,$ans) = @_;
      executeSql(DATABASE,"DELETE FROM error WHERE Ticket='$ticket'");
      print HTML::denySuccess($ans->[0]->{'NetID'},$ans->[0]->{'Hostname'});
      emailSomeone($ans->[0]->{'NetID'},$ans->[0]->{'Hostname'},"declined");
}
#========================================================================================================

#========================================================================================================
# emailSomeone(Requestee NetID, Hostname of Computer Up for Review, Review Decision)
#--------------------------------------------------------------------------------------------------------
# This function uses the sendmail tool native to Linux to send the email to the Requestee from the 
# Infrastructure Team - BCC Infrastructure Team
#========================================================================================================
sub emailSomeone {
	my ($netid,$host,$decision) =@_;
	my $smtpFH;

        open($smtpFH, "|/usr/lib/sendmail -t");
        print $smtpFH <<END_OF_HEADER;
To: <$netid\@txstate.edu>
From: "Infrastructure Team" <infra\@cs.txstate.edu>
BCC: "Infrastructure Team" <infra\@cs.txstate.edu>
Subject: NetBoot Registration for $host
The computer you submitted for approval, $host, has been $decision.
END_OF_HEADER
close($smtpFH);
}
#========================================================================================================

#========================================================================================================
# escapeSql(String to be escaped)
#--------------------------------------------------------------------------------------------------------
# Escapes the ' in the strings to \' in order to keep the parser in String mode.
#========================================================================================================
sub escapeSql
{
   my ($str)=@_;
   $str =~ s/\'/\\'/g;
   return $str;
}
#========================================================================================================

#========================================================================================================
# executeSql(Database Handle, SQL statement)
#--------------------------------------------------------------------------------------------------------
# Function to execute SQL. Don't touch. It works. Standard function in all of my programs.
#========================================================================================================
sub executeSql
{
   my ($this, $sql)=@_;
   my ($table);
  
   if($sql =~ m/^SELECT /i)
   {
      $table=$this->selectall_arrayref($sql, { Slice => {} }) ||
            die("Error Executing SQL: $sql\r\n".$this->errstr());
               return $table;
   }
   else
   {
      my ($statement);
      $statement=$this->prepare($sql) ||
           die("Error Preparing SQL: $sql\r\n".$this->errstr());
      $statement->execute() ||
           die("Error Executing SQL: $sql\r\n".$this->errstr());
                return undef;
   }
}
#========================================================================================================

