#!/usr/bin/perl
use strict;
use warnings;


#========================================================================================================
# We make use of MD5 to generate the token hash and LDAP to perform the authentication
#========================================================================================================
use Digest::MD5 qw(md5 md5_hex md5_base64);
use Net::LDAP;
#========================================================================================================


#========================================================================================================
# Declare the authentication package
#========================================================================================================
package Authentication;
#========================================================================================================


#========================================================================================================
# This is the TXSTATE LDAP authentication library.
# It enables authentication against the TXSTATE LDAP Active Directory domain via netid and password.
# It supports one-time sign on and allows transferring the authentication between web application run-time
#	environments via a standardized authentication cookie format.
# Once a user has been authenticated by the authentication library, any other pages that require authentication
#	will recognize the user has already been authenticated without prompting them again. The authentication
#	is said to be 'transitive'.
# The authentication session created by default lasts for AUTH_TIMEOUT minutes, any attempts after that
#	time will force reauthentication
# The checkAuth() function MUST be called after ALL headers have been output AND BEFORE any body content
#	has been output. This is because it set's authentication cookies and cannot do so if the body
#	has already been sent to the client.
#========================================================================================================

#========================================================================================================
# Author: Asa Yeamans (ay1067@txstate.edu) and Mason Egger (mme1@txstate.edu)
# Date: 2/16/2012
#
# Method of operation:
#	When a user is successfully authenticated via LDAP a cookie is sent back to the user containing:
#	- netid :	The netid used
#	- authTime :	The time of authentication
#	- authToken :	An MD5 has of the netid, the authentication time, and a secret hash key
#	When the user attempts to access a protected page, they present the 3 values.
#	The authLibrary then computes a hash based upon the user provided netid, the user provided time,
#	 and the secret hash key.
#	If the hashes DO NOT match, the user is forced to authenticate again.
#	If the hashes DO match, the time provided by the user is checked against the current time. If they
#	 differ by an amount greater than AUTH_TIMEOUT, the user is forced to authenticate again.
#	If the user attempts to impersonate someone other than themselves, they woudl have to create a
#	 hash based upon the fake username, a predetermined authentication time, and the secret password
#	 which will not be known to them. Therefore they cannot create this hash.
#	If the user attempts to replay the authentication, the timestamp will be too old.
# TL;DR
#	THE HASH SECRET KEY IS THE LYNCHPIN OF THIS AUTHENTICATION METHOD. IT MUST BE KEPT SECURE.
#========================================================================================================


#========================================================================================================
# Constants used in the script. These must be kept synchronized with the other authentication implementations
#	if there is to be SEAMLESS flow of credentials and single-sign-on-like behavior.
#========================================================================================================
use constant AUTH_TIMEOUT => 15;
use constant AUTH_HASH_SALT => '***removed***';

use constant AUTH_LDAP_SERVER => "ldaps://ldap.txstate.edu";
use constant AUTH_USER_OU => "CN=%s,OU=Txstate Users,DC=matrix,DC=txstate,DC=edu";
use constant AUTH_BASE_OU => "OU=Txstate Users,DC=matrix,DC=txstate,DC=edu";

# UNCOMMENT FOR CS DEPARTMENT LDAP SERVER AUTH
#use constant AUTH_LDAP_SERVER => "ldaps://leto.cs.txstate.edu";
#use constant AUTH_USER_OU => "UID=%s,OU=people,DC=linux,DC=cs,DC=txstate,DC=edu";
#use constant AUTH_BASE_OU => "OU=people,DC=linux,DC=cs,DC=txstate,DC=edu";
#========================================================================================================


#========================================================================================================
# Creates a new authentication object
#========================================================================================================
sub new
{
	my ($class, $args)=@_;


	my $this=bless({}, 'Authentication');
	$this->{_ldap}=Net::LDAP->new(AUTH_LDAP_SERVER);
	return $this;
}
#========================================================================================================


#========================================================================================================
# Contacts the LDAP directory server and attempts to bind as the given user object in the specified OU
#	with the given password. If the bind is successful (binding code is zero), then the credentials
#	were successfully validated. Otherwise, they were not correct.
#========================================================================================================
sub _validateCredentials
{
	my ($this, $username, $password)=@_;
	my ($bindCode, $userInfo);


	$bindCode=$this->{_ldap}->bind(sprintf(AUTH_USER_OU, $username), password=>$password, version=>3)->code();
		return (undef, undef, undef, undef) if($bindCode!=0);
	$userInfo=($this->{_ldap}->search(base=>AUTH_BASE_OU, scope=>"sub", attrs=>["cn","givenName","sn","txstatePersonID1"], filter=>"(|(cn=$username))")->entries())[0];

	return ($username, $userInfo->get_value("givenName"), $userInfo->get_value("sn"), $userInfo->get_value("txstatePersonID1"))
}
#========================================================================================================


#========================================================================================================
# Generates authentication token data packet for a given username and password, if they are correct. Otherwise
#	it returns empty data.
#========================================================================================================
sub createToken
{
	my ($this, $username, $password)=@_;
	my ($timestamp, $token, $firstName, $lastName, $studentID);


	#------------------------------------------------------------------------------------------------
	# If the user has not provided a username AND password, then fail authentication
	#------------------------------------------------------------------------------------------------
	return (undef, undef, undef, undef, undef, undef) if(($username eq '')||($password eq ''));
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# Perform the actual LDAP Authentication. Returns values on success, undefined if failure
	#------------------------------------------------------------------------------------------------
	($username, $firstName, $lastName, $studentID)=$this->_validateCredentials($username, $password);
		return (undef, undef, undef, undef, undef, undef) if(! defined($username));
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# Construct the authentication token data packet since authentication was successful
	#------------------------------------------------------------------------------------------------
	$timestamp=join('-', localtime());
	$token=Digest::MD5::md5_hex(AUTH_HASH_SALT . ".$username.$timestamp");
	#------------------------------------------------------------------------------------------------

	return ($username, $timestamp, $token, $firstName, $lastName, $studentID);
}
#========================================================================================================


#========================================================================================================
# Generates a NEW authentication token data packet when handed an existing, valid authentication token data packet.
#	This is used to extend the expiration.
#========================================================================================================
sub refreshToken
{
	my ($this, $username, $timestamp, $token)=@_;


	#------------------------------------------------------------------------------------------------
	# Verify that the authentication token data packet that was handed to us, is indeed valid and
	#	correct.
	#------------------------------------------------------------------------------------------------
	return (undef, undef, undef) if($this->validateToken($username, $timestamp, $token)==0);
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# Construct the NEW authentication token data packet since the old one validated correctly
	#------------------------------------------------------------------------------------------------
	$timestamp=join('-', localtime());
	$token=Digest::MD5::md5_hex(AUTH_HASH_SALT . ".$username.$timestamp");
	#------------------------------------------------------------------------------------------------

	return ($username, $timestamp, $token);
}
#========================================================================================================


#========================================================================================================
# Takes the pre-generated authentication token data packet and verifies its authenticity
#========================================================================================================
sub validateToken
{
	my ($this, $username, $timestamp, $token)=@_;
	my ($compareToken, @checkTimeArr, $checkTimeStamp, @authTimeArr, $authTimeStamp);


	#------------------------------------------------------------------------------------------------
	# Blank token data is not valid, must have a valid hash
	#------------------------------------------------------------------------------------------------
	return (undef, undef, undef) if(! defined($token));
	return (undef, undef, undef) if($token eq '');
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# Make sure the token we received is not a forged token, the hash of the salt, netid, and time
	#	provided should match the token that was provided, this is true ONLY as long as the HASH
	#	SALT value used in generating the hash **REMAINS SECRET**
	#------------------------------------------------------------------------------------------------
	$compareToken=Digest::MD5::md5_hex(AUTH_HASH_SALT . ".$username.$timestamp");
	return (undef, undef, undef) if($token ne $compareToken);
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# Now make sure the token hasn't expired by verifing that the authentication timestamp given happend
	#	AUTH_TIMEOUT minutes ago or less.
	#------------------------------------------------------------------------------------------------
	@checkTimeArr=localtime();
	$checkTimeStamp=($checkTimeArr[0] * 1) + ($checkTimeArr[1] * 60) + ($checkTimeArr[2] * 3600) + ($checkTimeArr[3] * 86400) + ($checkTimeArr[4] * 31536000);

	@authTimeArr=localtime();
	$authTimeStamp=($authTimeArr[0] * 1) + ($authTimeArr[1] * 60) + ($authTimeArr[2] * 3600) + ($authTimeArr[3] * 86400) + ($authTimeArr[4] * 31536000);

	return (undef, undef, undef) if(($checkTimeStamp - $authTimeStamp)>60*AUTH_TIMEOUT);
	#------------------------------------------------------------------------------------------------


	#------------------------------------------------------------------------------------------------
	# user is authenticated return true
	#------------------------------------------------------------------------------------------------
	return ($username, $timestamp, $token);
	#------------------------------------------------------------------------------------------------
}
#========================================================================================================


#========================================================================================================
# Returns the length of time, in minutes, a given authentication token data packet is valid for
#========================================================================================================
sub getTimeout
{
	return AUTH_TIMEOUT;
}
#========================================================================================================
1;
